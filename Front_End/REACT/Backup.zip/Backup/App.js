import logo from './logo.svg';
import './App.css';
import Nav from './components/Practice/Nav';
import Home from './components/Practice/Home';
import Text from './components/Practice/Text';

function App() {
  return (
    <div className="App">
      <Nav></Nav>
      <Home></Home>
      <Text></Text>
    </div>
  );
}

export default App;
